package com.nidansthan.astang;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends FragmentActivity {
    int[] chapterCount;
    List<Fragment> chapterFragments;
    ChapterList chapterList;
    int chaptercount;
    private MyAdapter mAdapter;
    private ViewPager mPager;

    class ChapterList {
        ChapterList() {
        }

        public void addChapter(int pos) {
            MainActivity.this.chapterFragments.addAll(getChapter(pos));
        }

        public List<Fragment> getChapter(int pos) {
            List<Fragment> list = new ArrayList();
            switch (pos) {
                case 0:
                    list.add(new Chapter1Page1());
                    list.add(new Chapter1Page2());
                    return list;
                case 1:
                    list.add(new Chapter2Page1());
                    list.add(new Chapter2Page2());
                    list.add(new Chapter2Page3());
                    list.add(new Chapter2Page4());
                    list.add(new Chapter2Page5());
                    list.add(new Chapter2Page6());
                    list.add(new Chapter2Page7());
                    return list;
                case 2:
                    list.add(new Chapter3Page1());
                    list.add(new Chapter3Page2());
                    return list;
                case 3:
                    list.add(new Chapter4Page1());
                    list.add(new Chapter4Page2());
                    return list;
                case 4:
                    list.add(new Chapter5Page1());
                    list.add(new Chapter5Page2());
                    list.add(new Chapter5Page3());
                    list.add(new Chapter5Page4());
                    list.add(new Chapter5Page5());
                    return list;
                case 5:
                    list.add(new Chapter6Page1());
                    list.add(new Chapter6Page2());
                    list.add(new Chapter6Page3());
                    return list;
                case 6:
                    list.add(new Chapter7Page1());
                    list.add(new Chapter7Page2());
                    list.add(new Chapter7Page3());
                    list.add(new Chapter7Page4());
                    return list;
                case 7:
                    list.add(new Chapter8Page1());
                    list.add(new Chapter8Page2());
                    return list;
                case 8:
                    list.add(new Chapter9Page1());
                    list.add(new Chapter9Page2());
                    list.add(new Chapter9Page3());
                    return list;
                case 9:
                    list.add(new Chapter10Page1());
                    list.add(new Chapter10Page2());
                    list.add(new Chapter10Page3());
                    return list;
                case 10:
                    list.add(new Chapter11Page1());
                    list.add(new Chapter11Page2());
                    list.add(new Chapter11Page3());
                    list.add(new Chapter11Page4());
                    return list;
                case 11:
                    list.add(new Chapter12Page1());
                    list.add(new Chapter12Page2());
                    list.add(new Chapter12Page3());
                    return list;
                case 12:
                    list.add(new Chapter13Page1());
                    list.add(new Chapter13Page2());
                    list.add(new Chapter13Page3());
                    list.add(new Chapter13Page4());
                    return list;
                case 13:
                    list.add(new Chapter14Page1());
                    list.add(new Chapter14Page2());
                    list.add(new Chapter14Page3());
                    list.add(new Chapter14Page4());
                    return list;
                case 14:
                    list.add(new Chapter15Page1());
                    list.add(new Chapter15Page2());
                    list.add(new Chapter15Page3());
                    list.add(new Chapter15Page4());
                    return list;
                case 15:
                    list.add(new Chapter16Page1());
                    list.add(new Chapter16Page2());
                    list.add(new Chapter16Page3());
                    return list;
                default:
                    return null;
            }
        }
    }

    public class MyAdapter extends FragmentPagerAdapter {
        public MyAdapter(FragmentManager fm) {
            super(fm);
        }

        public int getCount() {
            return 56;
        }

        public Fragment getItem(int position) {
            switch (position) {
                case 0:
                    return new Chapter1Page1();
                case 1:
                    return new Chapter1Page2();
                case 2:
                    return new Chapter2Page1();
                case 3:
                    return new Chapter2Page2();
                case 4:
                    return new Chapter2Page3();
                case 5:
                    return new Chapter2Page4();
                case 6:
                    return new Chapter2Page5();
                case 7:
                    return new Chapter2Page6();
                case 8:
                    return new Chapter2Page7();
                case 9:
                    return new Chapter3Page1();
                case 10:
                    return new Chapter3Page2();
                case 11:
                    return new Chapter4Page1();
                case 12:
                    return new Chapter4Page2();
                case 13:
                    return new Chapter5Page1();
                case 14:
                    return new Chapter5Page2();
                case 15:
                    return new Chapter5Page3();
                case 16:
                    return new Chapter5Page4();
                case 17:
                    return new Chapter5Page5();
                case 18:
                    return new Chapter6Page1();
                case 19:
                    return new Chapter6Page2();
                case 20:
                    return new Chapter6Page3();
                case 21:
                    return new Chapter7Page1();
                case 22:
                    return new Chapter7Page2();
                case 23:
                    return new Chapter7Page3();
                case 24:
                    return new Chapter7Page4();
                case 25:
                    return new Chapter8Page1();
                case 26:
                    return new Chapter8Page2();
                case 27:
                    return new Chapter9Page1();
                case 28:
                    return new Chapter9Page2();
                case 29:
                    return new Chapter9Page3();
                case 30:
                    return new Chapter10Page1();
                case 31:
                    return new Chapter10Page2();
                case 32:
                    return new Chapter10Page3();
                case 33:
                    return new Chapter11Page1();
                case 34:
                    return new Chapter11Page2();
                case 35:
                    return new Chapter11Page3();
                case 36:
                    return new Chapter11Page4();
                case 37:
                    return new Chapter12Page1();
                case 38:
                    return new Chapter12Page2();
                case 39:
                    return new Chapter12Page3();
                case 40:
                    return new Chapter13Page1();
                case 41:
                    return new Chapter13Page2();
                case 42:
                    return new Chapter13Page3();
                case 43:
                    return new Chapter13Page4();
                case 44:
                    return new Chapter13Page5();
                case 45:
                    return new Chapter14Page1();
                case 46:
                    return new Chapter14Page2();
                case 47:
                    return new Chapter14Page3();
                case 48:
                    return new Chapter14Page4();
                case 49:
                    return new Chapter15Page1();
                case 50:
                    return new Chapter15Page2();
                case 51:
                    return new Chapter15Page3();
                case 52:
                    return new Chapter15Page4();
                case 53:
                    return new Chapter16Page1();
                case 54:
                    return new Chapter16Page2();
                case 55:
                    return new Chapter16Page3();
                default:
                    return null;
            }
        }
    }

    public MainActivity() {
        int[] iArr = new int[16];
        iArr[1] = 2;
        iArr[2] = 9;
        iArr[3] = 11;
        iArr[4] = 13;
        iArr[5] = 18;
        iArr[6] = 21;
        iArr[7] = 25;
        iArr[8] = 27;
        iArr[9] = 30;
        iArr[10] = 33;
        iArr[11] = 37;
        iArr[12] = 40;
        iArr[13] = 45;
        iArr[14] = 49;
        iArr[15] = 53;
        this.chapterCount = iArr;
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0134R.layout.activity_main);
        this.chaptercount = getIntent().getIntExtra("selChapter", 0);
        this.mAdapter = new MyAdapter(getSupportFragmentManager());
        this.chapterFragments = new ArrayList();
        this.mPager = (ViewPager) findViewById(C0134R.id.pager);
        this.mPager.setAdapter(this.mAdapter);
        this.mPager.setCurrentItem(this.chapterCount[this.chaptercount]);
    }
}
