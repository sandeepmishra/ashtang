package com.nidansthan.astang;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.widget.ImageView;

public class SplashScreen extends Activity {
    Bitmap bitmap;
    ImageView imageView1;
    Thread thread;

    /* renamed from: com.nidansthan.astang.SplashScreen$1 */
    class C01351 implements Runnable {
        C01351() {
        }

        public void run() {
            SplashScreen splashScreen = SplashScreen.this;
            BitmapFactory bitmapFactory = new BitmapFactory();
            splashScreen.bitmap = BitmapFactory.decodeResource(SplashScreen.this.getResources(), C0134R.drawable.ic_splash);
            SplashScreen.this.imageView1.setImageBitmap(SplashScreen.this.bitmap);
        }
    }

    /* renamed from: com.nidansthan.astang.SplashScreen$2 */
    class C01362 implements Runnable {
        C01362() {
        }

        public void run() {
            try {
                synchronized (this) {
                    wait(3000);
                }
            } catch (Exception e) {
            }
            if (!SplashScreen.this.isFinishing()) {
                if (SplashScreen.this.bitmap != null) {
                    SplashScreen.this.bitmap.recycle();
                }
                SplashScreen.this.bitmap = null;
                SplashScreen.this.startActivity(new Intent(SplashScreen.this, ContentPage.class));
                SplashScreen.this.finish();
            }
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0134R.layout.splash_screen);
        this.imageView1 = (ImageView) findViewById(C0134R.id.imageView1);
        new Handler().postDelayed(new C01351(), 1500);
        this.thread = new Thread(new C01362());
        this.thread.start();
    }
}
