package com.nidansthan.astang;

import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class Chapter7Page1 extends Fragment {
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.e("Test", "hello");
    }

    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(C0134R.layout.chapter7page1, container, false);
        ((TextView) view.findViewById(C0134R.id.chapter7text1)).setTypeface(Typeface.createFromAsset(getActivity().getAssets(), "fonts/mangal.ttf"));
        return view;
    }
}
